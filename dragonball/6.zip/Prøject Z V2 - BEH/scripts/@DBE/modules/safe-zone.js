class SafeZone { constructor() { this._safeZones = []; } register(name, x, z, dimension, radius) { this._safeZones.push({ name: name, location: { x: x, z: z
}, dimension: dimension, radius: radius
}); } getAllSafeZones() { return this._safeZones; } } export const safeZone = new SafeZone();