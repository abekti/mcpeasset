import { LEGENDARY } from "../configs"; import { clamp, findTag, formatNumber, getForm, getRace, getScore, getTechnique } from "../utils"; // export function getStatsOLD(player, shadowDummy = false) {
//     const
//         raceMultiplier = getRace(player).multiplier,
//         formMultiplier = getForm(player).current.multiplier;
//     let totalStats = {
//         health: getScore(player, "dbe:statshea") * raceMultiplier.health * formMultiplier.health,
//         size: getScore(player, "dbe:statssiz") * raceMultiplier.size * formMultiplier.size,
//         speed: getScore(player, "dbe:statsspe") * raceMultiplier.speed * formMultiplier.speed,
//         strength: getScore(player, "dbe:statsstr") * raceMultiplier.strength * formMultiplier.strength,
//         kiConsume: getForm(player).current.id != getForm(player).unlocked[0].id ? formMultiplier.kiConsume * raceMultiplier.kiConsume : 0
//     };
//     // saiyan tail
//     if (getRace(player).id === "saiyan" && !player.hasTag("dbe:has_tail")) totalStats.health *= 1.1;
//     // legendary stats
//     if (player.hasTag("dbe:is_legendary")) {
//         totalStats.health *= LEGENDARY.multiplier.health;
//         totalStats.size *= LEGENDARY.multiplier.size;
//         totalStats.speed *= LEGENDARY.multiplier.speed;
//         totalStats.strength *= LEGENDARY.multiplier.strength;
//     };
//     // kaioken multiplier
//     if (player.hasTag("dbe:has_kaioken")) {
//         totalStats.speed *= getTechnique(player, "kaioken").current.multiplier.speed;
//         totalStats.strength *= getTechnique(player, "kaioken").current.multiplier.strength;
//     };
//     // fusion player 1
//     if (findTag(player, "dbe:fusion_player_1")) {
//         totalStats.health *= 1.1;
//         totalStats.size *= 1.1;
//         totalStats.speed *= 1.1;
//         totalStats.strength *= 1.1;
//     };
//     // fusion player 2
//     if (findTag(player, "dbe:fusion_player_2")) totalStats.size *= 0;
//     // weights speed
//     if (player.hasTag("dbe:piccolo_cape")) totalStats.speed -= 100;
//     if (player.hasTag("dbe:turtle_shell")) totalStats.speed -= 200;
//     if (player.hasTag("dbe:workout_weights")) totalStats.speed -= 300;
//     if (player.hasTag("dbe:hyperbolic_time_chamber")) totalStats.speed -= 400;
//     // no energy
//     if (getScore(player, "dbe:ki") <= 0 && !shadowDummy) {
//         totalStats.speed -= 100;
//         totalStats.strength -= 10;
//     }
//     // knocked out
//     if (player.hasTag("dbe:knocked_out")) {
//         totalStats.speed = 0;
//         totalStats.strength = 0;
//     }
//     const stats = {
//         health: clamp(Math.round(totalStats.health), 0, 1000),
//         size: clamp(Math.round(totalStats.size), 0, 200),
//         speed: clamp(Math.round(totalStats.speed) + 500, 0, 1500),
//         strength: clamp(Math.round(totalStats.strength), 0, 1000),
//         kiConsume: totalStats.kiConsume,
//         bp: formatNumber(Math.max(Math.round(totalStats.health * totalStats.strength), 0))
//     };
//     return stats;
// }
export function getStats(player, stat, shadowDummy = false) { const
raceMultiplier = getRace(player).multiplier, formMultiplier = getForm(player).current.multiplier; switch (stat) { case "health":
let health = getScore(player, "dbe:statshea") * raceMultiplier.health * formMultiplier.health; if (getRace(player).id === "saiyan" && !player.hasTag("dbe:has_tail")) health *= 1.1; if (player.hasTag("dbe:is_legendary")) health *= LEGENDARY.multiplier.health; if (findTag(player, "dbe:fusion_player_1")) health *= 1.1; return clamp(Math.round(health), 0, 1000); case "size":
let size = getScore(player, "dbe:statssiz") * raceMultiplier.size * formMultiplier.size; if (player.hasTag("dbe:is_legendary")) size *= LEGENDARY.multiplier.size; if (findTag(player, "dbe:fusion_player_1")) size *= 1.1; if (findTag(player, "dbe:fusion_player_2")) size *= 0; return clamp(Math.round(size), 0, 200); case "speed":
let speed = getScore(player, "dbe:statsspe") * raceMultiplier.speed * formMultiplier.speed; if (player.hasTag("dbe:is_legendary")) speed *= LEGENDARY.multiplier.speed; if (player.hasTag("dbe:has_kaioken")) speed *= getTechnique(player, "kaioken").current.multiplier.speed; if (findTag(player, "dbe:fusion_player_1")) speed *= 1.1; if (player.hasTag("dbe:piccolo_cape")) speed -= 100; if (player.hasTag("dbe:turtle_shell")) speed -= 200; if (player.hasTag("dbe:workout_weights")) speed -= 300; if (player.hasTag("dbe:hyperbolic_time_chamber")) speed -= 400; if (getScore(player, "dbe:ki") <= 0 && !shadowDummy) speed -= 100; if (player.hasTag("dbe:knocked_out")) speed = 0; return clamp(Math.round(speed) + 500, 0, 1500); case "strength":
let strength = getScore(player, "dbe:statsstr") * raceMultiplier.strength * formMultiplier.strength; if (player.hasTag("dbe:is_legendary")) strength *= LEGENDARY.multiplier.strength; if (player.hasTag("dbe:has_kaioken")) strength *= getTechnique(player, "kaioken").current.multiplier.strength; if (findTag(player, "dbe:fusion_player_1")) strength *= 1.1; if (getScore(player, "dbe:ki") <= 0 && !shadowDummy) strength -= 10; if (player.hasTag("dbe:knocked_out")) strength = 0; return clamp(Math.round(strength), 0, 1000); case "ki_consume":
let kiConsume = getForm(player).current.id != getForm(player).unlocked[0].id ? formMultiplier.kiConsume * raceMultiplier.kiConsume : 0; return kiConsume; case "bp": return formatNumber(Math.max(Math.round(getStats(player, "health") * getStats(player, "strength")), 0)); } }