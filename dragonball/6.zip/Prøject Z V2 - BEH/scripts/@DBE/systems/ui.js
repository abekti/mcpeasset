import { world } from "@minecraft/server"; import { ActionFormData } from "@minecraft/server-ui"; import { getForm, getRace, getScore, getTechnique } from "../utils"; import { getStats } from "../modules"; import { MISSIONS } from "../configs"; world.events.beforeItemUse.subscribe(data => { const player = data.source; switch (data.item.typeId) { case "dbe:change_hair":
if (getRace(player).id === "saiyan") selectHair(player); break; case "dbe:menu":
!player.hasTag("dbe:select_race") ? menu(player) : v3BetaSaiyan(player); // !player.hasTag("dbe:select_race") ? menu(player) : selectRace(player)
break; case "dbe:functions":
if (!player.hasTag("dbe:select_race")) functions(player); break; } }); function v3BetaSaiyan(player) { player.triggerEvent("dbe:saiyan"); player.addTag("dbe:update_stats"); player.addTag("dbe:has_tail"); player.runCommandAsync("scoreboard players set @s dbe:race 1"); customization(player); } function attributes(player) { const form = new ActionFormData(); form.title("ui.attributes.title"); form.body(`CON ${getStats(player, "health")}:   §9100 TP\n§rSPE ${getStats(player, "speed")}:   §9100 TP\n§rSTR ${getStats(player, "strength")}:   §9100 TP\n§rKI ${getScore(player, "dbe:maxki")}:   §9100 TP\n\n§rTP: ${getScore(player, "dbe:tp")}`); form.button(""); form.button("+"); form.button("+"); form.button("+"); form.button("+"); form.button("+"); form.show(player).then(response => { if (response.canceled) player.addTag("dbe:update_stats"); switch (response.selection) { case 0:
menu(player); break; case 1:
if (getScore(player, "dbe:tp") >= 100 && getScore(player, "dbe:statshea") < 250) { player.runCommandAsync("scoreboard players remove @s dbe:tp 100"); player.runCommandAsync("scoreboard players add @s dbe:statshea 1"); player.tell({ rawtext: [{ text: "§a + 1 CON" }] }); } else player.tell({ rawtext: [{ translate: "learn.error.1" }] }); attributes(player); break; case 2:
if (getScore(player, "dbe:tp") >= 100 && getScore(player, "dbe:statsspe") < 250) { player.runCommandAsync("scoreboard players remove @s dbe:tp 100"); player.runCommandAsync("scoreboard players add @s dbe:statsspe 1"); player.tell({ rawtext: [{ text: "§a + 1 SPE" }] }); } else player.tell({ rawtext: [{ translate: "learn.error.1" }] }); attributes(player); break; case 3:
if (getScore(player, "dbe:tp") >= 100 && getScore(player, "dbe:statsstr") < 250) { player.runCommandAsync("scoreboard players remove @s dbe:tp 100"); player.runCommandAsync("scoreboard players add @s dbe:statsstr 1"); player.tell({ rawtext: [{ text: "§a + 1 STR" }] }); } else player.tell({ rawtext: [{ translate: "learn.error.1" }] }); attributes(player); break; case 4:
if (getScore(player, "dbe:tp") >= 100) { player.runCommandAsync("scoreboard players add @s dbe:kibackup 20"); player.runCommandAsync("scoreboard players add @s dbe:maxki 20"); player.runCommandAsync("scoreboard players remove @s dbe:tp 100"); player.tell({ rawtext: [{ text: "§a + 1 KI" }] }); } else player.tell({ rawtext: [{ translate: "learn.error.1" }] }); attributes(player); break; case 5:
attributes(player); break; } }); } function customization(player) { const form = new ActionFormData(); form.title("ui.customization.title"); form.body(`Genero\nSkin\nCabelo\nCor do KI`); form.button(""); form.button("ui.customization.select"); form.button(""); form.button(""); form.button(""); form.button(""); form.button(""); form.button(""); form.show(player).then(response => { if (response.canceled) customization(player); switch (response.selection) { case 0:
// player.addTag("dbe:select_race");
// selectRace(player)
customization(player); break; case 1:
player.removeTag("dbe:select_race"); player.triggerEvent("dbe:daily"); menu(player); break; case 2:
player.triggerEvent("dbe:change_genre"); customization(player); break; case 3:
player.triggerEvent("dbe:change_genre"); customization(player); break; case 4:
player.triggerEvent("dbe:change_skin_back"); customization(player); break; case 5:
player.triggerEvent("dbe:change_skin_next"); customization(player); break; case 6:
player.triggerEvent("dbe:change_saiyan_hair_back"); customization(player); break; case 7:
player.triggerEvent("dbe:change_saiyan_hair_next"); customization(player); break; case 8:
customization(player); break; case 9:
customization(player); break; } }); } function functions(player) { const form = new ActionFormData(); form.title("ui.functions.title"); form.body(""); form.button(player.hasTag("dbe:has_kaioken") ? getTechnique(player, "kaioken").current.id : ""); form.button(getForm(player).selected.id); form.button(player.hasTag("dbe:has_ultra_instinct") ? getTechnique(player, "ultra_instinct").current.id : ""); form.button(player.hasTag("dbe:friendly_fist") ? "Friendly Fist ON" : "Friendly Fist OFF"); form.button("ui.functions.button.4"); form.button(player.hasTag("dbe:has_ki_scythe") ? "Foice de ki" : ""); form.button(""); form.button(getRace(player).id === "saiyan" ? "Tail Mode" : ""); form.button(""); form.show(player).then(response => { switch (response.selection) { case 0:
if (player.hasTag("dbe:has_kaioken")) { (getScore(player, "dbe:kaioken") < getTechnique(player, "kaioken").list.length - 1 ?
player.runCommandAsync("scoreboard players add @s dbe:kaioken 1") :
player.runCommandAsync("scoreboard players set @s dbe:kaioken 0")) .then(() => { player.addTag("dbe:update_stats"); player.tell({ rawtext: [{ text: "§6" }, { translate: getTechnique(player, "kaioken").list[getScore(player, "dbe:kaioken")].id }] }); player.runCommandAsync("particle dbe:kaioken_sphere ~~~"); functions(player); }); } break; case 1:
(getScore(player, "dbe:selectedform") < getForm(player).unlocked.length - 1 ?
player.runCommandAsync("scoreboard players add @s dbe:selectedform 1") :
player.runCommandAsync("scoreboard players set @s dbe:selectedform 0")) .then(() => functions(player)); break; case 2:
if (player.hasTag("dbe:has_ultra_instinct") && getForm(player).selected.id !== "oozaru") { (getScore(player, "dbe:mui") < getTechnique(player, "ultra_instinct").list.length - 1 ?
player.runCommandAsync("scoreboard players add @s dbe:mui 1") :
player.runCommandAsync("scoreboard players set @s dbe:mui 0")) .then(() => { player.addTag("dbe:update_stats"); player.triggerEvent(`dbe:${getTechnique(player, "ultra_instinct").list[getScore(player, "dbe:mui")].id}`); functions(player); }); } break; case 3:
if (player.hasTag("dbe:friendly_fist")) player.removeTag("dbe:friendly_fist"); else player.addTag("dbe:friendly_fist"); functions(player); break; case 5:
if (player.hasTag("dbe:has_ki_scythe")) player.triggerEvent("dbe:ki_scythe"); break; case 7:
if (getRace(player).id === "saiyan") player.triggerEvent("dbe:tail_curled"); functions(player); break; } }); } function menu(player) { const form = new ActionFormData(); form.title("ui.menu.title"); form.button("ui.menu.button.1"); form.button("ui.menu.button.2"); form.button("ui.menu.button.3"); form.button("ui.menu.button.4"); form.show(player).then(response => { switch (response.selection) { case 0:
attributes(player); break; case 1:
skills(player); break; case 2:
mission(player); break; case 3:
if (getScore(player, "dbe:timersha") === 0) { player.runCommandAsync(`summon dbe:shadow_dummy`); player.runCommandAsync("scoreboard players set @s dbe:timersha 5"); } break; } }); } function mission(player) { const form = new ActionFormData(); form.title("ui.missions.title"); form.body(`${MISSIONS.list[getScore(player, "dbe:mission")].title.enUS}\n\n${MISSIONS.list[getScore(player, "dbe:mission")].description.enUS}\n\n${MISSIONS.list[getScore(player, "dbe:mission")].objective.enUS}`); form.button(""); form.button("start"); form.show(player).then(response => { switch (response.selection) { case 0:
menu(player); break; case 1:
player.addTag("dbe:start_mission"); break; } }); } function selectHair(player) { const form = new ActionFormData(); form.title("ui.select_hair.title"); form.body(""); form.button(""); form.button(""); form.button(""); form.show(player).then(response => { switch (response.selection) { case 0:
player.triggerEvent("dbe:change_saiyan_hair_back"); selectHair(player); break; case 1:
break; case 2:
player.triggerEvent("dbe:change_saiyan_hair_next"); selectHair(player); break; } }); } function selectRace(player) { const form = new ActionFormData(); form.title("ui.select_race.title"); form.body(""); form.button(""); form.button("ui.select_race.select"); form.button(""); form.show(player).then(response => { if (response.canceled && player.hasTag("dbe:select_race")) { player.triggerEvent("dbe:human"); selectRace(player); } switch (response.selection) { case 0:
player.triggerEvent("dbe:change_race_back"); selectRace(player); break; case 1:
player.removeTag("dbe:select_race"); player.triggerEvent("dbe:set_race"); customization(player); break; case 2:
player.triggerEvent("dbe:change_race_next"); selectRace(player); break; } }); } function skills(player) { const
superForm = getScore(player, "dbe:superform"), price = getRace(player).superFormPrices[getScore(player, "dbe:superform")], tp = getScore(player, "dbe:tp"), form = new ActionFormData(); form.title("ui.skills.title"); form.body(`Super Forma ${superForm}: §9${price} TP`); form.button(""); form.button("+"); form.show(player).then(response => { switch (response.selection) { case 0:
menu(player); break; case 1:
if (tp >= price) { player.runCommandAsync(`scoreboard players remove @s dbe:tp ${price}`); player.runCommandAsync("scoreboard players add @s dbe:superform 1").then(() => skills(player)); } else if (superForm != getForm(player).unlocked.length - 1) { player.tell({ rawtext: [{ translate: "learn.error.1" }] }); skills(player); } break; } }); }