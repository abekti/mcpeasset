/*
|--------------------------------------------------------------
| Configurar lendário
|--------------------------------------------------------------
*/
export const LEGENDARY = {
    percentage: 4,
    multiplier: {
        health: 1.1,
        size: 1.1,
        speed: 1.1,
        strength: 1.1,
        kiConsume: 1
    }
};