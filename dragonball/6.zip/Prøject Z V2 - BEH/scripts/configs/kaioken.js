/*
|--------------------------------------------------------------
| Configurar kaioken
|--------------------------------------------------------------
*/
export const KAIOKEN = [
    {
        id: "kaioken_off",
        multiplier: {
            speed: 1,
            strength: 1
        }
    },
    {
        id: "kaioken",
        damage: 10,
        multiplier: {
            speed: 1.05,
            strength: 1.05
        }
    },
    {
        id: "kaioken_x3",
        damage: 20,
        multiplier: {
            speed: 1.1,
            strength: 1.1
        }
    },
    {
        id: "kaioken_x10",
        damage: 40,
        multiplier: {
            speed: 1.15,
            strength: 1.15
        }
    },
    {
        id: "kaioken_x20",
        damage: 70,
        multiplier: {
            speed: 1.2,
            strength: 1.2
        }
    }
];