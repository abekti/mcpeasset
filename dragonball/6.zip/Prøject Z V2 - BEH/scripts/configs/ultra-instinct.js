/*
|--------------------------------------------------------------
| Configurar instinto superior
|--------------------------------------------------------------
*/
export const ULTRA_INSTINCT = [
    {
        id: "ultra_instinct_off",
        dodgeRate: 0
    },
    {
        id: "incomplete_ultra_instinct",
        dodgeRate: 50
    },
    {
        id: "ultra_instinct",
        dodgeRate: 50
    }
];