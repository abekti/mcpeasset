/*
|--------------------------------------------------------------
| Configurar ou adicionar missões
| Aqui você pode modificar ou adicionar mais missões
| Todas as missões são modulares e vão se adaptar conforme a configuração
| Siga esse modelo:
|
|   {
|       title: {
|           enUS: "",
|           ptBR: ""
|       },
|       description: {
|           enUS: "",
|           ptBR: ""
|       },
|       objective: {
|           enUS: "",
|           ptBR: ""
|       },
|       reward: [valor da recompensa em TP],
|       timer: [missão deve ter tempo?],
|       summon: [missão deve spawnar os mobs ao iniciar?],
|       enemies: [
|           "minecraft:pig",
|           "dbe:saibaman",
|           "[adicione seu inimigo aqui]"
|       ]
|   },
|
| Não esqueça das vírgulas!
|--------------------------------------------------------------
*/
export const MISSIONS = {
    expireTime: 60,
    list: [
        {
            title: {
                enUS: "§l§athe dinosaurs are chasing you!!!",
                ptBR: "§l§aos dinossauros estão te perseguindo!!!"
            },
            description: {
                enUS: "§l§a3 dinossauros estão perseguindo você",
                ptBR: "§l§a3 dinossauros estão perseguindo você"
            },
            objective: {
                enUS: "§c§lKill 3 dinosaur",
                ptBR: "§l§cMate 3 dinossauros"
            },
            reward: 200,
            timer: true,
            summon: true,
            enemies: [
                "dbe:dinosaur",
                "dbe:dinosaur",
                "dbe:dinosaur",
            ]
        },
        {
            title: {
                enUS: "§l§aYamcha the thief of the right?",
                ptBR: "§l§aYamcha o ladrão da direita?"
            },
            description: {
                enUS: "§l§aI think he wants the dragon balls defeat him to find out more",
                ptBR: "§l§aAcho que ele quer que as esferas do dragão o derrotem para saber mais"
            },
            objective: {
                enUS: "§l§cDefeat Yamcha",
                ptBR: "§l§cDerrotar yamcha"
            },
            reward: 300,
            timer: true,
            summon: true,
            enemies: [
                "dbe:yamcha"
            ]
        },
        {
            title: {
                enUS: "§l§aThey want to steal the dragon balls!?",
                ptBR: "§l§aEles querem roubar as esferas do dragão!?"
            },
            description: {
                enUS: "§l§cpilaf and his allies want the dragon balls",
                ptBR: "§l§cpilaf e seus aliados querem as esferas do dragão"
            },
            objective: {
                enUS: "§l§cDefeat shu",
                ptBR: "§l§cDerrotar shu"
            },
            reward: 200,
            timer: true,
            summon: true,
            enemies: [
                "dbe:shu"
            ]
        },
        {
            title: {
                enUS: "§l§aThey want to steal the dragon balls!?",
                ptBR: "§l§aEles querem roubar as esferas do dragão!?"
            },
            description: {
                enUS: "§l§apilaf and his allies want the dragon balls",
                ptBR: "§l§apilaf e seus aliados querem as esferas do dragão"
            },
            objective: {
                enUS: "§l§cDefeat mai",
                ptBR: "§l§cDerrotar mai"
            },
            reward: 200,
            timer: true,
            summon: true,
            enemies: [
                "dbe:mai"
            ]
        },
        {
            title: {
                enUS: "§l§aThey want to steal the dragon balls!?",
                ptBR: "§l§aEles querem roubar as esferas do dragão!?"
            },
            description: {
                enUS: "§l§apilaf and his allies want the dragon balls",
                ptBR: "§l§apilaf e seus aliados querem as esferas do dragão"
            },
            objective: {
                enUS: "§l§cDefeat pilaf",
                ptBR: "§l§cDerrotar pilaf"
            },
            reward: 200,
            timer: true,
            summon: true,
            enemies: [
                "dbe:pilaf"
            ]
        },
        {
            title: {
                enUS: "§l§aNow they have robots!?",
                ptBR: "§l§aAgora eles têm robôs!?"
            },
            description: {
                enUS: "§l§apilaf and his allies want the dragon balls",
                ptBR: "§l§apilaf e seus aliados querem as esferas do dragão"
            },
            objective: {
                enUS: "§l§cDefeat shu",
                ptBR: "§l§cDerrotar shu"
            },
            reward: 200,
            timer: true,
            summon: true,
            enemies: [
                "dbe:mecha_shu"
            ]
        },
        {
            title: {
                enUS: "§l§aNow they have robots!?",
                ptBR: "§l§aAgora eles têm robôs!?"
            },
            description: {
                enUS: "§l§apilaf and his allies want the dragon balls",
                ptBR: "§l§apilaf e seus aliados querem as esferas do dragão"
            },
            objective: {
                enUS: "§l§cDefeat mai",
                ptBR: "§l§cDerrotar mai"
            },
            reward: 200,
            timer: true,
            summon: true,
            enemies: [
                "dbe:mecha_mai"
            ]
        },
        {
            title: {
                enUS: "§l§aNow they have robots!?",
                ptBR: "§l§aAgora eles têm robôs!?"
            },
            description: {
                enUS: "§l§apilaf and his allies want the dragon balls",
                ptBR: "§l§apilaf e seus aliados querem as esferas do dragão"
            },
            objective: {
                enUS: "§l§cDefeat pilaf",
                ptBR: "§l§cDerrotar pilaf"
            },
            reward: 200,
            timer: true,
            summon: true,
            enemies: [
                "dbe:mecha_pilaf"
            ]
        },
        {
            title: {
                enUS: "§l§aWho are the Saiyans?",
                ptBR: "§l§aSaiyajins?"
            },
            description: {
                enUS: "§l§aKill Saibamans to gather more information. They can be found in rocky biomes.",
                ptBR: "§l§aUma grande energia se aproxima rapidamente... Mate Saibamans para coletar mais informções."
            },
            objective: {
                enUS: "§l§cKill 6 Saibamans",
                ptBR: "§l§cMate 6 Saibamans"
            },
            reward: 400,
            timer: false,
            summon: false,
            enemies: [
                "dbe:saibaman",
                "dbe:saibaman",
                "dbe:saibaman",
                "dbe:saibaman",
                "dbe:saibaman",
                "dbe:saibaman"
            ]
        },
        {
            title: {
                enUS: "§l§aArrival of Raditz",
                ptBR: "§l§aChegada de Raditz"
            },
            description: {
                enUS: "§l§aRaditz has just arrived on Earth looking for her brother, who was sent here when he was still a baby.",
                ptBR: "§l§aRaditz acaba de chegar na Terra à procura de seu irmão, que foi enviado aqui quando ainda era um bebê."
            },
            objective: {
                enUS: "§l§cKill Raditz",
                ptBR: "§l§cMate Raditz"
            },
            reward: 500,
            timer: true,
            summon: true,
            enemies: [
                "dbe:raditz"
            ]
        },
        {
            title: {
                enUS: "§l§aMore Saiyans?",
                ptBR: "§l§aMais Saiyajins?"
            },
            description: {
                enUS: "§l§aBefore he died, Raditz told him that there are 2 other Sayajins more powerful than him on their way to Earth.",
                ptBR: "§l§aAntes de morrer, Raditz lhe contou que existem outros 2 Sayajins mais poderosos que ele à caminho da Terra."
            },
            objective: {
                enUS: "§l§cKill 8 Saibamans",
                ptBR: "§l§cMate 8 Saibamans"
            },
            reward: 400,
            timer: false,
            summon: true,
            enemies: [
                "dbe:saibaman",
                "dbe:saibaman",
                "dbe:saibaman",
                "dbe:saibaman",
                "dbe:saibaman",
                "dbe:saibaman",
                "dbe:saibaman",
                "dbe:saibaman"
            ]
        },
        {
            title: {
                enUS: "§l§aVegeta and Nappa",
                ptBR: "§l§aVegeta e Nappa"
            },
            description: {
                enUS: "§l§aThey have arrived and want to destroy the Earth. Do not allow!",
                ptBR: "§l§aEles chegaram e querem acabar com a Terra. Não permita!"
            },
            objective: {
                enUS: "§l§cKill Nappa",
                ptBR: "§l§cMate Nappa"
            },
            reward: 1000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:nappa"
            ]
        },
        {
            title: {
                enUS: "§l§aVegeta and Nappa",
                ptBR: "§l§aVegeta e Nappa"
            },
            description: {
                enUS: "§l§aThey have arrived and want to destroy the Earth. Do not allow!",
                ptBR: "§l§aEles chegaram e querem acabar com a Terra. Não permita!"
            },
            objective: {
                enUS: "§l§cKill Vegeta",
                ptBR: "§l§cMate Vegeta"
            },
            reward: 1000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:vegeta"
            ]
        },
        {
            title: {
                enUS: "§l§aWho is Freeza?",
                ptBR: "§l§aQuem é Freeza?"
            },
            description: {
                enUS: "§l§aSoldiers everywhere in Namek! Where did they come from and why?",
                ptBR: "§l§aSoldados em todo lugar em Namek! De onde saíram e por que?"
            },
            objective: {
                enUS: "§l§cKill 10 Freeza Soldiers",
                ptBR: "§l§cMate 10 Soldados do Freeza"
            },
            reward: 2000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier"
            ]
        },
        {
            title: {
                enUS: "§l§aNew danger!",
                ptBR: "§l§aNovo perigo!"
            },
            description: {
                enUS: "§l§aWhat is this? More powerful than me? Impossible! Nobody could!",
                ptBR: "§l§aO que é isso? Mais poderoso que eu? Impossível! Ninguém poderia!"
            },
            objective: {
                enUS: "§l§cKill Cui",
                ptBR: "§l§cMate Cui"
            },
            reward: 1000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:cui"
            ]
        },
        {
            title: {
                enUS: "§l§aDodoria finds you!",
                ptBR: "§l§aDodoria te encontra!"
            },
            description: {
                enUS: "§l§aYou won't believe it! I am the most powerful!",
                ptBR: "§l§aVocê não vai acreditar! Eu sou o mais poderoso!"
            },
            objective: {
                enUS: "§l§cKill Dodoria",
                ptBR: "§l§cMate Dodoria"
            },
            reward: 1000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:dodoria"
            ]
        },
        {
            title: {
                enUS: "§l§aZarbon do something!",
                ptBR: "§l§aZarbon faça alguma coisa!"
            },
            description: {
                enUS: "§l§aLooks like Zarbon will fight you, or else he'll be killed by Frieza... Well, he'll be killed anyway if he gets in your way.",
                ptBR: "§l§aParece que Zarbon lutará com você, ou então será morto por Freeza... Bom, ele será morto de qualquer forma se ficar no seu caminho."
            },
            objective: {
                enUS: "§l§cKill Zarbon",
                ptBR: "§l§cMate Zarbon"
            },
            reward: 2000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:zarbon"
            ]
        },
        {
            title: {
                enUS: "§l§aGinyu Special Forces",
                ptBR: "§l§aForças especiais Ginyu"
            },
            description: {
                enUS: "§l§aI'm Recoome, I'm Burter, Jeice, Guldo, Captain Ginyu... And we're all together... Ginyu special forces! Huh?",
                ptBR: "§l§aSou Recoome, sou Burter, Jeice, Guldo, Capitão Ginyu... E todos juntos somos... As forças especiais Gyniu! Hein?"
            },
            objective: {
                enUS: "§l§cdefeat the Ginyu special forces",
                ptBR: "§l§cDerrote as forças especiais Gyniu"
            },
            reward: 2000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:burter"
            ]
        },
        {
            title: {
                enUS: "§l§aGinyu Special Forces",
                ptBR: "§l§aForças especiais Ginyu"
            },
            description: {
                enUS: "§l§aI'm Recoome, I'm Burter, Jeice, Guldo, Captain Ginyu... And we're all together... Ginyu special forces! Huh?",
                ptBR: "§l§aSou Recoome, sou Burter, Jeice, Guldo, Capitão Ginyu... E todos juntos somos... As forças especiais Gyniu! Hein?"
            },
            objective: {
                enUS: "§l§cdefeat the Ginyu special forces",
                ptBR: "§l§cDerrote as forças especiais Gyniu"
            },
            reward: 2000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:guldo"
            ]
        },
        {
            title: {
                enUS: "§l§aGinyu Special Forces",
                ptBR: "§l§aForças especiais Ginyu"
            },
            description: {
                enUS: "§l§aI'm Recoome, I'm Burter, Jeice, Guldo, Captain Ginyu... And we're all together... Ginyu special forces! Huh?",
                ptBR: "§l§aSou Recoome, sou Burter, Jeice, Guldo, Capitão Ginyu... E todos juntos somos... As forças especiais Gyniu! Hein?"
            },
            objective: {
                enUS: "§l§cdefeat the Ginyu special forces",
                ptBR: "§l§cDerrote as forças especiais Gyniu"
            },
            reward: 2000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:recoome"
            ]
        },
        {
            title: {
                enUS: "§l§aGinyu Special Forces",
                ptBR: "§l§aForças especiais Ginyu"
            },
            description: {
                enUS: "§l§aI'm Recoome, I'm Burter, Jeice, Guldo, Captain Ginyu... And we're all together... Ginyu special forces! Huh?",
                ptBR: "§l§aSou Recoome, sou Burter, Jeice, Guldo, Capitão Ginyu... E todos juntos somos... As forças especiais Gyniu! Hein?"
            },
            objective: {
                enUS: "§l§cdefeat the Ginyu special forces",
                ptBR: "§l§cDerrote as forças especiais Gyniu"
            },
            reward: 2000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:jeice"
            ]
        },
        {
            title: {
                enUS: "§l§aGinyu Special Forces",
                ptBR: "§l§aForças especiais Ginyu"
            },
            description: {
                enUS: "§l§aI'm Recoome, I'm Burter, Jeice, Guldo, Captain Ginyu... And we're all together... Ginyu special forces! Huh?",
                ptBR: "§l§aSou Recoome, sou Burter, Jeice, Guldo, Capitão Ginyu... E todos juntos somos... As forças especiais Gyniu! Hein?"
            },
            objective: {
                enUS: "§l§cdefeat the Ginyu special forces",
                ptBR: "§l§cDerrote as forças especiais Gyniu"
            },
            reward: 2500,
            timer: true,
            summon: true,
            enemies: [
                "dbe:ginyu"
            ]
        },
        {
            title: {
                enUS: "§l§aWe don't forgive!",
                ptBR: "§l§aNão perdoamos!"
            },
            description: {
                enUS: "§l§aYou ruined my plans, my strengths and my desires! Now... how would you like to be killed?",
                ptBR: "§l§aVocê arruinou meus planos, minhas forças e meus desejos! Agora... como gostaria de ser morto?"
            },
            objective: {
                enUS: "§l§cKill Freeza",
                ptBR: "§l§cMate Freeza"
            },
            reward: 4000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:freeza"
            ]
        },
        {
            title: {
                enUS: "§l§aFreeza Retorna!",
                ptBR: "§l§aFreeza Retorna!"
            },
            description: {
                enUS: "",
                ptBR: ""
            },
            objective: {
                enUS: "§l§cKill Freeza and King Cold",
                ptBR: "§l§cMate Freeza e Rei Cold"
            },
            reward: 2500,
            timer: true,
            summon: true,
            enemies: [
                "dbe:king_cold",
                "dbe:mecha_freeza"
            ]
        },
        {
            title: {
                enUS: "§l§aOs Terríveis Androides N° 19 e 20!",
                ptBR: "§l§aOs Terríveis Androides N° 19 e 20!"
            },
            description: {
                enUS: "",
                ptBR: ""
            },
            objective: {
                enUS: "§l§cKill Android 19 and Android 20",
                ptBR: "§l§cMate os Androides N° 19 e 20"
            },
            reward: 3000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:android_19",

            ]
        },
        {
            title: {
                enUS: "§l§aOs Terríveis Androides N° 19 e 20!",
                ptBR: "§l§aOs Terríveis Androides N° 19 e 20!"
            },
            description: {
                enUS: "",
                ptBR: ""
            },
            objective: {
                enUS: "§l§cKill Android 19 and Android 20",
                ptBR: "§l§cMate os Androides N° 19 e 20"
            },
            reward: 3000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:android_20",

            ]
        },
        {
            title: {
                enUS: "§l§aO despertar dos Androides N° 17 e 18",
                ptBR: "§l§aO despertar dos Androides N° 17 e 18"
            },
            description: {
                enUS: "",
                ptBR: ""
            },
            objective: {
                enUS: "§l§cKill Android 17",
                ptBR: "§l§cMate o Androide 17"
            },
            reward: 3500,
            timer: true,
            summon: true,
            enemies: [
                "dbe:android_17"
            ]
        },
        {
            title: {
                enUS: "§l§aO despertar dos Androides N° 17 e 18",
                ptBR: "§l§aO despertar dos Androides N° 17 e 18"
            },
            description: {
                enUS: "",
                ptBR: ""
            },
            objective: {
                enUS: "§l§cKill Android 18",
                ptBR: "§l§cMate o Androide N° 18"
            },
            reward: 3500,
            timer: true,
            summon: true,
            enemies: [
                "dbe:android_18"
            ]
        },
        {
            title: {
                enUS: "§l§aew ew ew ew eww",
                ptBR: "§l§aew ew ew ew eww asco"
            },
            description: {
                enUS: "",
                ptBR: ""
            },
            objective: {
                enUS: "§l§cDefeat all cell junior's",
                ptBR: "§l§cDerrotar os cell juniors"
            },
            reward: 3000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:cell_junior",
                "dbe:cell_junior",
                "dbe:cell_junior",
                "dbe:cell_junior",
                "dbe:cell_junior",
                "dbe:cell_junior"
            ]
        },
        {
            title: {
                enUS: "§l§aO Monstro Misterioso!",
                ptBR: "§l§aO Monstro Misterioso!"
            },
            description: {
                enUS: "",
                ptBR: ""
            },
            objective: {
                enUS: "§l§cKill Cell",
                ptBR: "§l§cMate Cell"
            },
            reward: 5000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:cell"
            ]
        },
        {
            title: {
                enUS: "§l§abroly has a lot of accumulated ki defeat him to end this massacre",
                ptBR: "§l§abroly quere liberar seu ki derrita a ele"
            },
            description: {
                enUS: "§6§lbroly the legendary super saiyan",
                ptBR: "§6§lbroly o saiyajin lendario"
            },
            objective: {
                enUS: "§l§cdefeat broly",
                ptBR: "§l§cderrotar broly"
            },
            reward: 6000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:broly"
            ]
        },
        {
            title: {
                enUS: "§l§abroly woke up goten wants to fight but he is weak defeat him",
                ptBR: "§l§aO broly desperto o goten quere lutar pero ele e debil derrotalo"
            },
            description: {
                enUS: "§6§lgoten son of goku",
                ptBR: "§6§lgoten hijo do goku"
            },
            objective: {
                enUS: "§l§cdefeat goten",
                ptBR: "§l§cderrotar goten"
            },
            reward: 4000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:goten"
            ]
        },
        {
            title: {
                enUS: "§l§atrunks you too?",
                ptBR: "§l§atrunks vc tambem?"
            },
            description: {
                enUS: "§6§ltrunks son of vegeta",
                ptBR: "§6§ltrunks hijo do vegeta"
            },
            objective: {
                enUS: "§l§cdefeat trunks",
                ptBR: "§l§cderrotar trunks"
            },
            reward: 4500,
            timer: true,
            summon: true,
            enemies: [
                "dbe:trunks"
            ]
        },
        {
            title: {
                enUS: "§l§abroly has woken up",
                ptBR: "§l§abroly despertou"
            },
            description: {
                enUS: "§6§lbroly the legendary saiyajin",
                ptBR: "§6§lbroly o saiyajin lendario"
            },
            objective: {
                enUS: "§l§cdefeat broly",
                ptBR: "§l§cderrotar broly"
            },
            reward: 4000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:broly"
            ]
        },
        {
            title: {
                enUS: "§l§aa doctor created broly with cells but everything went wrong",
                ptBR: "§l§aUm doctor crio uma verssao de broly pero tudo saiu mau"
            },
            description: {
                enUS: "§6§lbio-broly?",
                ptBR: "§6§lbio-broly?"
            },
            objective: {
                enUS: "§l§cdefeat bio-broly",
                ptBR: "§l§cderrotar bio-broly"
            },
            reward: 6000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:bio_broly"
            ]
        },
        {
            title: {
                enUS: "§l§ayamu and spopovich defeat videl and gohan i swear to take revenge defeat them now!!!",
                ptBR: "§l§ayamu e spopovich derrotam videl e gohan eu juro me vingar derrote-os agora!!!"
            },
            description: {
                enUS: "§l§ayamu and spopovich defeat videl and gohan i swear to take revenge defeat them now!!!",
                ptBR: "§l§ayamu e spopovich derrotam videl e gohan eu juro me vingar derrote-os agora!!!"
            },
            objective: {
                enUS: "§l§cKill yamu",
                ptBR: "§l§cMate yamu"
            },
            reward: 3000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:yamu",
            ]
        },
        {
            title: {
                enUS: "§l§ayamu and spopovich defeat videl and gohan i swear to take revenge defeat them now!!!",
                ptBR: "§l§ayamu e spopovich derrotam videl e gohan eu juro me vingar derrote-os agora!!!"
            },
            description: {
                enUS: "§l§ayamu and spopovich defeat videl and gohan i swear to take revenge defeat them now!!!",
                ptBR: "§l§ayamu e spopovich derrotam videl e gohan eu juro me vingar derrote-os agora!!!"
            },
            objective: {
                enUS: "§l§cKill spopobich",
                ptBR: "§l§cMate spopobich"
            },
            reward: 3000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:spopobich",
            ]
        },
        {
            title: {
                enUS: "§l§aPui Pui warns them that any injuries they receive will be energy that Buu will receive.",
                ptBR: "§l§aPui Pui os avisa que qualquer ferimento que receberem será energia que Buu receberá."
            },
            description: {
                enUS: "§l§aPui Pui warns them that any injuries they receive will be energy that Buu will receive.",
                ptBR: "§l§aPui Pui os avisa que qualquer ferimento que receberem será energia que Buu receberá."
            },
            objective: {
                enUS: "§l§cKill pui pui",
                ptBR: "§l§cMate pui pui"
            },
            reward: 3500,
            timer: true,
            summon: true,
            enemies: [
                "dbe:pui_pui",
            ]
        },
        {
            title: {
                enUS: "§l§aGoku transforms into Super Saiyan but this time with a much greater intensity, and Yakon weakens from so much energy it's time to defeat him",
                ptBR: "§l§aGoku se transforma em Super Saiyajin mas dessa vez com uma intensidade muito maior, e Yakon enfraquece de tanta energia que é hora de derrotá-lo"
            },
            description: {
                enUS: "§l§a3 Goku transforms into Super Saiyan but this time with a much greater intensity, and Yakon weakens from so much energy it's time to defeat him",
                ptBR: "§l§aGoku se transforma em Super Saiyajin mas dessa vez com uma intensidade muito maior, e Yakon enfraquece de tanta energia que é hora de derrotá-lo"
            },
            objective: {
                enUS: "§l§cKill yakon",
                ptBR: "§l§cMate yakon"
            },
            reward: 4000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:yakon",
            ]
        },
        {
            title: {
                enUS: "§l§aThe combat is very hard and you have got the upper hand",
                ptBR: "§l§aO combate é muito difícil e você leva vantagem"
            },
            description: {
                enUS: "§l§aThe combat is very hard and you have got the upper hand",
                ptBR: "§l§aO combate é muito difícil e você leva vantagem."
            },
            objective: {
                enUS: "§l§cKill dabura",
                ptBR: "§l§cMate dabura"
            },
            reward: 5000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:dabura",
            ]
        },
        {
            title: {
                enUS: "§l§aYou fight with Vegeta Super Saiyan 2, and the injuries are incredibly serious",
                ptBR: "§l§aVocê luta com Vegeta Super Saiyan 2, e os ferimentos são incrivelmente graves"
            },
            description: {
                enUS: "§l§aYou fight with Vegeta Super Saiyan 2, and the injuries are incredibly serious",
                ptBR: "§l§aVocê luta com Vegeta Super Saiyan 2, e os ferimentos são incrivelmente graves"
            },
            objective: {
                enUS: "§l§cKill majin vegeta",
                ptBR: "§l§cMate majin vegeta"
            },
            reward: 5000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:majin_vegeta",
            ]
        },
        {
            title: {
                enUS: "§l§a(Vegeta would sacrifice himself) Piccolo thanks Vegeta for his sacrifice, but terrified he watches as cell by cell Majin Buu begins to regenerate.",
                ptBR: "§l§a(Vegeta se sacrificaria) Piccolo agradece a Vegeta por seu sacrifício, mas apavorado ele assiste célula por célula Majin Boo começar a se regenerar."
            },
            description: {
                enUS: "§l§a(Vegeta would sacrifice himself) Piccolo thanks Vegeta for his sacrifice, but terrified he watches as cell by cell Majin Buu begins to regenerate.",
                ptBR: "§l§a(Vegeta se sacrificaria) Piccolo agradece a Vegeta por seu sacrifício, mas apavorado ele assiste célula por célula Majin Boo começar a se regenerar."
            },
            objective: {
                enUS: "§l§cKill majin bu",
                ptBR: "§l§cMate majin bu"
            },
            reward: 5500,
            timer: true,
            summon: true,
            enemies: [
                "dbe:majin_bu",
            ]
        },
        {
            title: {
                enUS: "§l§aSuddenly Buu expels all his anger and a new Buu (Bad Buu) comes out of him",
                ptBR: "§l§aDe repente Buu expele toda sua raiva e um novo Buu (Bad Buu) sai dele"
            },
            description: {
                enUS: "§l§aSuddenly Buu expels all his anger and a new Buu (Bad Buu) comes out of him",
                ptBR: "§l§aDe repente Buu expele toda sua raiva e um novo Buu (Bad Buu) sai dele"
            },
            objective: {
                enUS: "§l§cKill evil bu",
                ptBR: "§l§cMate o mau majin buu"
            },
            reward: 6000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:majin_bu_1",
            ]
        },
        {
            title: {
                enUS: "§l§aa vaia do mal absorveu a vaia do bem",
                ptBR: "§l§aa vaia do mal absorveu a vaia do bem"
            },
            description: {
                enUS: "§l§aa vaia do mal absorveu a vaia do bem",
                ptBR: "§l§aa vaia do mal absorveu a vaia do bem"
            },
            objective: {
                enUS: "§l§cKill majin bu",
                ptBR: "§l§cMate majin buu"
            },
            reward: 6000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:majin_bu_2",
            ]
        },
        {
            title: {
                enUS: "§l§abuu absorve gotenks e aumenta seu poder",
                ptBR: "§l§abuu absorve gotenks e aumenta seu poder"
            },
            description: {
                enUS: "§l§abuu absorve gotenks e aumenta seu poder",
                ptBR: "§l§abuu absorve gotenks e aumenta seu poder"
            },
            objective: {
                enUS: "§l§cKill majin bu",
                ptBR: "§l§cMate majin bu"
            },
            reward: 6000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:majin_bu_3",
            ]
        },
        {
            title: {
                enUS: "§l§aBuu absorve Gohan e aumenta seu poder muito mais",
                ptBR: "§l§aBuu absorve Gohan e aumenta seu poder muito mais"
            },
            description: {
                enUS: "§l§aBuu absorve Gohan e aumenta seu poder muito mais",
                ptBR: "§l§aBuu absorve Gohan e aumenta seu poder muito mais"
            },
            objective: {
                enUS: "§l§cKill majin bu",
                ptBR: "§l§cMate majin bu"
            },
            reward: 5000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:majin_bu_4",
            ]
        },
        {
            title: {
                enUS: "§l§aBuu absorve Gohan e aumenta seu poder muito mais",
                ptBR: "§l§aBuu absorve Gohan e aumenta seu poder muito mais"
            },
            description: {
                enUS: "§l§aBuu absorve Gohan e aumenta seu poder muito mais",
                ptBR: "§l§aBuu absorve Gohan e aumenta seu poder muito mais"
            },
            objective: {
                enUS: "§l§cKill ",
                ptBR: "§l§cMate "
            },
            reward: 7000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:majin_bu_5",
            ]
        },
        {
            title: {
                enUS: "§l§abu libertou todos para alcançar sua forma final",
                ptBR: "§l§abu libertou todos para alcançar sua forma final"
            },
            description: {
                enUS: "§l§abu libertou todos para alcançar sua forma final",
                ptBR: "§l§abu libertou todos para alcançar sua forma final"
            },
            objective: {
                enUS: "§l§cKill majin bu",
                ptBR: "§l§cMate majin bu"
            },
            reward: 8000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:majin_bu_6",
            ]
        },
        {
            title: {
                enUS: "§l§aSaga Super",
                ptBR: "§l§aSaga Super"
            },
            description: {
                enUS: "§l§athe god of destruction has arrived with the help of your friends you obtained the power of a god",
                ptBR: "§l§ao deus da destruição chegou com a ajuda de seus amigos você obteve o poder de um deus"
            },
            objective: {
                enUS: "§l§cdefeat billz ",
                ptBR: "§l§cderrotar billz "
            },
            reward: 8500,
            timer: true,
            summon: true,
            enemies: [
                "dbe:bilz",
            ]
        },
        {
            title: {
                enUS: "§l§aSaga Super",
                ptBR: "§l§aSaga Super"
            },
            description: {
                enUS: "§l§athe emperor frieza arrived with his allies",
                ptBR: "§l§ao imperador frieza chegou com seus aliados"
            },
            objective: {
                enUS: "§l§cdefeat 10 soldiers ",
                ptBR: "§l§cderrotar 10 soldados "
            },
            reward: 3000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier"
            ]
        },
        {
            title: {
                enUS: "§l§aSaga Super",
                ptBR: "§l§aSaga Super"
            },
            description: {
                enUS: "§l§athe soldiers are too many",
                ptBR: "§l§aos soldados são demais"
            },
            objective: {
                enUS: "§l§cdefeat 20 soldiers ",
                ptBR: "§l§cderrotar 20 soldados "
            },
            reward: 6000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier",
                "dbe:freeza_soldier"
            ]
        },
        {
            title: {
                enUS: "§l§aSaga Super",
                ptBR: "§l§aSaga Super"
            },
            description: {
                enUS: "§l§aFreeza's strongest soldiers arrived Tagoma and Shisami",
                ptBR: "§l§aOs soldados mais fortes de Freeza chegaram Tagoma e Shisami"
            },
            objective: {
                enUS: "§l§cdefeat shisami ",
                ptBR: "§l§cderrotar shisami "
            },
            reward: 7000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:shisami",
            ]
        },
        {
            title: {
                enUS: "§l§aSaga Super",
                ptBR: "§l§aSaga Super"
            },
            description: {
                enUS: "§l§aFreeza's strongest soldiers arrived Tagoma and Shisami",
                ptBR: "§l§aOs soldados mais fortes de Freeza chegaram Tagoma e Shisami"
            },
            objective: {
                enUS: "§l§cdefeat tagoma ",
                ptBR: "§l§cderrotar tagoma "
            },
            reward: 7000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:tagoma",
            ]
        },
        {
            title: {
                enUS: "§l§aSaga Super",
                ptBR: "§l§aSaga Super"
            },
            description: {
                enUS: "§l§asoldier tagoma has changed bodies with ginyu",
                ptBR: "§l§asoldado tagoma mudou de corpo com ginyu"
            },
            objective: {
                enUS: "§l§cdefeat ginyu ",
                ptBR: "§l§cderrotar ginyu "
            },
            reward: 7000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:tagoma",
            ]
        },
        {
            title: {
                enUS: "§l§aSaga Super",
                ptBR: "§l§aSaga Super"
            },
            description: {
                enUS: "§l§athe real battle begins frieza vs his enemy",
                ptBR: "§l§aa verdadeira batalha começa frieza contra seu inimigo"
            },
            objective: {
                enUS: "§l§cdefeat freezer ",
                ptBR: "§l§cderrotar freezer "
            },
            reward: 10000,
            timer: true,
            summon: true,
            enemies: [
                "dbe:freezer_super",
            ]
        }
    ]
};
