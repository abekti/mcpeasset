/*
|--------------------------------------------------------------
| Configurar desejos do Shenlong
|--------------------------------------------------------------
*/
export const SHENLONG_WISHES = [
    {
        type: "item",
        name: "dbe:katchin_shard",
        count: 2
    },
    {
        type: "item",
        name: "dbe:potara_earrings",
        count: 1
    },
    {
        type: "item",
        name: "dbe:senzu_bean",
        count: 3
    },
    {
        type: "item",
        name: "dbe:warenai",
        count: 19
    },
    {
        type: "item",
        name: "minecraft:diamond",
        count: 16
    },
    {
        type: "tag",
        name: "dbe:has_divine_ki"
    },
    {
        type: "tag",
        name: "dbe:is_legendary"
    }
];