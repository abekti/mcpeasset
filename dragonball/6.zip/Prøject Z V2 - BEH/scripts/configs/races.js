/*
|--------------------------------------------------------------
| Configurar raças
|--------------------------------------------------------------
*/
export const RACES = [
    {
        id: "human",
        multiplier: {
            health: 1,
            size: 1,
            speed: 1.1,
            strength: 1,
            kiConsume: 1,
            regeneration: 2
        },
        superFormPrices: [
            1200,
            2000,
            3000
        ],
        forms: [
            {
                id: "human_base",
                superForm: 0,
                multiplier: {
                    health: 1,
                    size: 1,
                    speed: 1.05,
                    strength: 1.05,
                    kiConsume: 1
                }
            },
            {
                id: "human_buffed",
                superForm: 1,
                multiplier: {
                    health: 1.3,
                    size: 1.05,
                    speed: 1.3,
                    strength: 1.3,
                    kiConsume: 2
                }
            },
            {
                id: "human_full_released",
                superForm: 2,
                multiplier: {
                    health: 1.8,
                    size: 1.1,
                    speed: 1.8,
                    strength: 1.8,
                    kiConsume: 3
                }
            },
            {
                id: "human_god",
                superForm: 3,
                multiplier: {
                    health: 2.6,
                    size: 1,
                    speed: 2.6,
                    strength: 2.6,
                    kiConsume: 4
                }
            }
        ]
    },
    {
        id: "saiyan",
        multiplier: {
            health: 1,
            size: 1,
            speed: 1,
            strength: 1,
            kiConsume: 1,
            regeneration: 1
        },
        superFormPrices: [
            1800,
            2500,
            4000,
            8000,
            10000,
            14000,
            18000,
            25000,
            30000,
            40000,
            50000
        ],
        forms: [
            {
                id: "saiyan_base",
                superForm: 0,
                multiplier: {
                    health: 1,
                    size: 1,
                    speed: 1,
                    strength: 1.1,
                    kiConsume: 1
                }
            },
            {
                id: "oozaru",
                superForm: 0,
                multiplier: {
                    health: 1.3,
                    size: 2,
                    speed: 1.3,
                    strength: 1.3,
                    kiConsume: 1
                },
                tagCondition: [
                    "dbe:has_tail",
                    "dbe:is_night"
                ]
            },
            {
                id: "super_saiyan",
                superForm: 1,
                multiplier: {
                    health: 1.6,
                    size: 1,
                    speed: 1.6,
                    strength: 1.6,
                    kiConsume: 2
                }
            },
            {
                id: "super_saiyan_grade_2",
                superForm: 2,
                multiplier: {
                    health: 1.8,
                    size: 1.15,
                    speed: 1.6,
                    strength: 1.8,
                    kiConsume: 2
                }
            },
            {
                id: "super_saiyan_2",
                superForm: 3,
                multiplier: {
                    health: 2,
                    size: 1.05,
                    speed: 2,
                    strength: 2,
                    kiConsume: 2
                }
            },
            {
                id: "super_saiyan_3",
                superForm: 4,
                multiplier: {
                    health: 2.2,
                    size: 1.1,
                    speed: 2.2,
                    strength: 2.2,
                    kiConsume: 4
                }
            },
            {
                id: "golden_oozaru",
                superForm: 5,
                multiplier: {
                    health: 2.25,
                    size: 2,
                    speed: 2.25,
                    strength: 2.25,
                    kiConsume: 1
                },
                tagCondition: [
                    "dbe:has_tail",
                    "dbe:is_night"
                ]
            },
            {
                id: "super_saiyan_4",
                superForm: 6,
                multiplier: {
                    health: 2.4,
                    size: 1.1,
                    speed: 2.4,
                    strength: 2.4,
                    kiConsume: 2
                },
                tagCondition: [
                    "dbe:has_tail"
                ]
            },
            {
                id: "super_saiyan_god",
                superForm: 7,
                multiplier: {
                    health: 2.5,
                    size: 1,
                    speed: 2.5,
                    strength: 2.5,
                    kiConsume: 1
                }
            },
            {
                id: "super_saiyan_blue",
                superForm: 8,
                multiplier: {
                    health: 2.6,
                    size: 1,
                    speed: 2.6,
                    strength: 2.6,
                    kiConsume: 5
                }
            },
            {
                id: "super_saiyan_rose",
                superForm: 8,
                multiplier: {
                    health: 2.6,
                    size: 1,
                    speed: 2.6,
                    strength: 2.6,
                    kiConsume: 5
                }
            },
            {
                id: "super_saiyan_blue_evolution",
                superForm: 9,
                multiplier: {
                    health: 2.8,
                    size: 1,
                    speed: 2.8,
                    strength: 2.8,
                    kiConsume: 6
                }
            },
            {
                id: "super_saiyan_rose_evolution",
                superForm: 9,
                multiplier: {
                    health: 2.8,
                    size: 1,
                    speed: 2.8,
                    strength: 2.8,
                    kiConsume: 6
                }
            },
            {
                id: "Beast",
                superForm: 10,
                multiplier: {
                    health: 2.9,
                    size: 1,
                    speed: 2.9,
                    strength: 2.9,
                    kiConsume: 7
                }
            },
            {
                id: "Ultra ego",
                superForm: 11,
                multiplier: {
                    health: 3,
                    size: 1,
                    speed: 3,
                    strength: 3,
                    kiConsume: 8
                }
            }
        ]
    },
    {
        id: "namekian",
        multiplier: {
            health: 1.1,
            size: 1,
            speed: 1,
            strength: 1,
            kiConsume: 1,
            regeneration: 4
        },
        superFormPrices: [
            1200,
            2000,
            3000
        ],
        forms: [
            {
                id: "namekian_base",
                superForm: 0,
                multiplier: {
                    health: 1,
                    size: 1,
                    speed: 1,
                    strength: 1,
                    kiConsume: 1
                }
            },
            {
                id: "namekian_giant",
                superForm: 1,
                multiplier: {
                    health: 1.5,
                    size: 2,
                    speed: 1.5,
                    strength: 1.5,
                    kiConsume: 1
                }
            },
            {
                id: "namekian_full_released",
                superForm: 2,
                multiplier: {
                    health: 1.8,
                    size: 1.1,
                    speed: 1.8,
                    strength: 1.8,
                    kiConsume: 2
                }
            },
            {
                id: "namekian_potential_unleashed",
                superForm: 3,
                multiplier: {
                    health: 2.75,
                    size: 1,
                    speed: 2.75,
                    strength: 2.75,
                    kiConsume: 2
                }
            }
        ]
    },
    {
        id: "arcosian",
        multiplier: {
            health: 1.05,
            size: 1,
            speed: 1,
            strength: 1.05,
            kiConsume: 1,
            regeneration: 3
        },
        superFormPrices: [
            1200,
            2000,
            3000,
            5000,
            5500
        ],
        forms: [
            {
                id: "arcosian_base",
                superForm: 0,
                multiplier: {
                    health: 1,
                    size: 1,
                    speed: 1,
                    strength: 1,
                    kiConsume: 1
                }
            },
            {
                id: "arcosian_second_form",
                superForm: 1,
                multiplier: {
                    health: 1.6,
                    size: 1.05,
                    speed: 1.6,
                    strength: 1.6,
                    kiConsume: 1
                }
            },
            {
                id: "arcosian_third_form",
                superForm: 2,
                multiplier: {
                    health: 1.8,
                    size: 1.1,
                    speed: 1.8,
                    strength: 1.8,
                    kiConsume: 1
                }
            },
            {
                id: "arcosian_fourth_form",
                superForm: 3,
                multiplier: {
                    health: 2.1,
                    size: 1,
                    speed: 2.1,
                    strength: 2.1,
                    kiConsume: 2
                }
            },
            {
                id: "golden_arcosian",
                superForm: 4,
                multiplier: {
                    health: 2.8,
                    size: 1,
                    speed: 2.8,
                    strength: 2.8,
                    kiConsume: 3
                }
            },
            {
                id: "black_arcosian",
                superForm: 5,
                multiplier: {
                    health: 2.85,
                    size: 1.05,
                    speed: 2.85,
                    strength: 2.85,
                    kiConsume: 4
                }
            }
        ]
    }
];